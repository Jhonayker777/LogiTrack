package LogiTrack.API.service.impl;

import LogiTrack.API.dto.request.ProductoDtoRequest;
import LogiTrack.API.dto.response.ProductoDtoResponse;
import LogiTrack.API.mapper.ProductoMapper;
import LogiTrack.API.Model.Producto;
import LogiTrack.API.repository.ProductoRepository;
import LogiTrack.API.service.ProductoService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductoServiceImpl implements ProductoService {

    private final ProductoRepository productoRepository;
    private final ProductoMapper productoMapper;

    @Override
    @Transactional(readOnly = true)
    public List<ProductoDtoResponse> listarTodos() {
        return productoRepository.findAll().stream()
                .map(productoMapper::entityToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProductoDtoResponse> listarStockBajo() {
        return productoRepository.findProductosStockBajo().stream()
                .map(productoMapper::entityToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public ProductoDtoResponse buscarPorId(Long id) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + id));
        return productoMapper.entityToDto(producto);
    }

    @Override
    @Transactional
    public ProductoDtoResponse guardar(ProductoDtoRequest dto) {
        if (productoRepository.existsByNombre(dto.nombre())) {
            throw new RuntimeException("Ya existe un producto con el nombre: " + dto.nombre());
        }

        Producto producto = productoMapper.DtoToEntity(dto);
        Producto productoGuardado = productoRepository.save(producto);
        return productoMapper.entityToDto(productoGuardado);
    }

    @Override
    @Transactional
    public ProductoDtoResponse actualizar(Long id, ProductoDtoRequest dto) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + id));

        // ✅ Usamos updateEntityFromDto
        productoMapper.updateEntityFromDto(producto, dto);

        Producto productoActualizado = productoRepository.save(producto);
        return productoMapper.entityToDto(productoActualizado);
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        if (!productoRepository.existsById(id)) {
            throw new RuntimeException("Producto no encontrado con ID: " + id);
        }
        productoRepository.deleteById(id);
    }
}
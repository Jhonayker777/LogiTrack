package LogiTrack.API.service;

import LogiTrack.API.dto.request.DepartamentoDtoRequest;
import LogiTrack.API.dto.response.DepartamentoDtoResponse;

import java.util.List;

public interface DepartamentoService {
    List<DepartamentoDtoResponse> listarTodos();

    DepartamentoDtoResponse buscarPorId(Long id);

    DepartamentoDtoResponse guardar(DepartamentoDtoRequest dto);

    DepartamentoDtoResponse actualizar(Long id, DepartamentoDtoRequest dto);

    void eliminar(Long id);
}
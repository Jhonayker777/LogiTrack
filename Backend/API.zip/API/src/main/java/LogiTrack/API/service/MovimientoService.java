package LogiTrack.API.service;

import LogiTrack.API.dto.request.MovimientoDtoRequest;
import LogiTrack.API.dto.response.MovimientoDtoResponse;

import java.util.List;

public interface MovimientoService {
    MovimientoDtoResponse registrarMovimiento(MovimientoDtoRequest dto, String usernameUsuario);

    List<MovimientoDtoResponse> listarTodos();

    MovimientoDtoResponse buscarPorId(Long id);
}
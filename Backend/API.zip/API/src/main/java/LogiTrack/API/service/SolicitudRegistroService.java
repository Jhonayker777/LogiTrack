package LogiTrack.API.service;

import LogiTrack.API.dto.request.AprobacionDtoRequest;
import LogiTrack.API.dto.request.RechazoDtoRequest;
import LogiTrack.API.dto.request.SolicitudRegistroDtoRequest;
import LogiTrack.API.dto.response.SolicitudRegistroDtoResponse;

import java.util.List;

public interface SolicitudRegistroService {

    // Para el aspirante
    SolicitudRegistroDtoResponse solicitarRegistro(SolicitudRegistroDtoRequest dto);

    // Para el administrador
    SolicitudRegistroDtoResponse aprobarSolicitud(Long id, String usernameAdmin);
    SolicitudRegistroDtoResponse rechazarSolicitud(Long id, RechazoDtoRequest dto, String usernameAdmin);

    // Consultas
    List<SolicitudRegistroDtoResponse> listarTodas();
    List<SolicitudRegistroDtoResponse> listarPorEstado(String estado);
    SolicitudRegistroDtoResponse buscarPorId(Long id);
}
package LogiTrack.API.service;

import LogiTrack.API.dto.request.ProductoDtoRequest;
import LogiTrack.API.dto.response.ProductoDtoResponse;

import java.util.List;

public interface ProductoService {
    List<ProductoDtoResponse> listarTodos();

    List<ProductoDtoResponse> listarStockBajo();

    ProductoDtoResponse buscarPorId(Long id);

    ProductoDtoResponse guardar(ProductoDtoRequest dto);

    ProductoDtoResponse actualizar(Long id, ProductoDtoRequest dto);

    void eliminar(Long id);
}
package LogiTrack.API.service.impl;

import LogiTrack.API.dto.request.DepartamentoDtoRequest;
import LogiTrack.API.dto.response.DepartamentoDtoResponse;
import LogiTrack.API.mapper.DepartamentoMapper;
import LogiTrack.API.Model.Departamento;
import LogiTrack.API.repository.DepartamentoRepository;
import LogiTrack.API.service.DepartamentoService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DepartamentoServiceImpl implements DepartamentoService {

    private final DepartamentoRepository departamentoRepository;
    private final DepartamentoMapper departamentoMapper;

    @Override
    @Transactional(readOnly = true)
    public List<DepartamentoDtoResponse> listarTodos() {
        return departamentoRepository.findAll().stream()
                .map(departamentoMapper::entityToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public DepartamentoDtoResponse buscarPorId(Long id) {
        Departamento departamento = departamentoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Departamento no encontrado con ID: " + id));
        return departamentoMapper.entityToDto(departamento);
    }

    @Override
    @Transactional
    public DepartamentoDtoResponse guardar(DepartamentoDtoRequest dto) {
        if (departamentoRepository.existsByNombre(dto.nombre())) {
            throw new RuntimeException("Ya existe un departamento con el nombre: " + dto.nombre());
        }
        Departamento departamento = departamentoMapper.DtoToEntity(dto);
        return departamentoMapper.entityToDto(departamentoRepository.save(departamento));
    }

    @Override
    @Transactional
    public DepartamentoDtoResponse actualizar(Long id, DepartamentoDtoRequest dto) {
        Departamento departamento = departamentoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Departamento no encontrado con ID: " + id));

        departamentoMapper.updateEntityFromDto(departamento, dto);

        return departamentoMapper.entityToDto(departamentoRepository.save(departamento));
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        if (!departamentoRepository.existsById(id)) {
            throw new RuntimeException("Departamento no encontrado con ID: " + id);
        }
        departamentoRepository.deleteById(id);
    }
}
package LogiTrack.API.service.implement;

import LogiTrack.API.dto.request.BodegaDtoRequest;
import LogiTrack.API.dto.response.BodegaDtoResponse;
import LogiTrack.API.dto.response.CiudadDtoResponse;
import LogiTrack.API.dto.response.UsuarioResumenDtoResponse;
import LogiTrack.API.mapper.BodegaMapper;
import LogiTrack.API.mapper.CiudadMapper;
import LogiTrack.API.mapper.DepartamentoMapper;
import LogiTrack.API.mapper.UsuarioMapper;
import LogiTrack.API.Model.Bodega;
import LogiTrack.API.Model.Ciudad;
import LogiTrack.API.Model.Usuario;
import LogiTrack.API.repository.BodegaRepository;
import LogiTrack.API.repository.CiudadRepository;
import LogiTrack.API.repository.UsuarioRepository;
import LogiTrack.API.service.BodegaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BodegaServiceImpl implements BodegaService {

    private final BodegaRepository bodegaRepository;
    private final UsuarioRepository usuarioRepository;
    private final CiudadRepository ciudadRepository;

    private final BodegaMapper bodegaMapper;
    private final UsuarioMapper usuarioMapper;
    private final CiudadMapper ciudadMapper;
    private final DepartamentoMapper departamentoMapper;

    @Override
    public BodegaDtoResponse guardar(BodegaDtoRequest dto) {
        Usuario encargado = usuarioRepository.findById(dto.encargadoId())
                .orElseThrow(() -> new RuntimeException("El usuario encargado no existe"));

        Ciudad ciudad = ciudadRepository.findById(dto.ciudadId())
                .orElseThrow(() -> new RuntimeException("La ciudad no existe"));

        Bodega bodega = bodegaMapper.DtoToEntity(dto, encargado, ciudad);
        Bodega guardada = bodegaRepository.save(bodega);

        // Preparamos los DTOs anidados para el response
        UsuarioResumenDtoResponse encargadoDto = usuarioMapper.entityToResumenDto(guardada.getEncargado());
        CiudadDtoResponse ciudadDto = ciudadMapper.entityToDto(guardada.getCiudad(), departamentoMapper.entityToDto(guardada.getCiudad().getDepartamento()));

        return bodegaMapper.entityToDto(guardada, encargadoDto, ciudadDto);
    }

    @Override
    public BodegaDtoResponse actualizar(BodegaDtoRequest dto, Long id) {
        Bodega bodega = bodegaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Bodega no encontrada con ID: " + id));

        Usuario encargado = usuarioRepository.findById(dto.encargadoId())
                .orElseThrow(() -> new RuntimeException("El usuario encargado no existe"));

        Ciudad ciudad = ciudadRepository.findById(dto.ciudadId())
                .orElseThrow(() -> new RuntimeException("La ciudad no existe"));

        // Aquí usamos el updateEntityFromDto
        bodegaMapper.updateEntityFromDto(bodega, dto, encargado, ciudad);
        Bodega actualizada = bodegaRepository.save(bodega);

        UsuarioResumenDtoResponse encargadoDto = usuarioMapper.entityToResumenDto(actualizada.getEncargado());
        CiudadDtoResponse ciudadDto = ciudadMapper.entityToDto(actualizada.getCiudad(), departamentoMapper.entityToDto(actualizada.getCiudad().getDepartamento()));

        return bodegaMapper.entityToDto(actualizada, encargadoDto, ciudadDto);
    }

    @Override
    public void eliminar(Long id) {
        Bodega bodega = bodegaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Bodega no encontrada con ID: " + id));
        bodegaRepository.delete(bodega);
    }

    @Override
    public List<BodegaDtoResponse> listar() {
        return bodegaRepository.findAll().stream().map(
                b -> bodegaMapper.entityToDto(b,
                        usuarioMapper.entityToResumenDto(b.getEncargado()),
                        ciudadMapper.entityToDto(b.getCiudad(), departamentoMapper.entityToDto(b.getCiudad().getDepartamento())))
        ).toList();
    }

    @Override
    public BodegaDtoResponse buscarId(Long id) {
        Bodega bodega = bodegaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Bodega no encontrada con ID: " + id));

        return bodegaMapper.entityToDto(bodega,
                usuarioMapper.entityToResumenDto(bodega.getEncargado()),
                ciudadMapper.entityToDto(bodega.getCiudad(), departamentoMapper.entityToDto(bodega.getCiudad().getDepartamento())));
    }
}